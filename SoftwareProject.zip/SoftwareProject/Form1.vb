﻿Public Class Form1

    Private Sub Btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub Btnadminpfp_Click(sender As Object, e As EventArgs) Handles btnadminpfp.Click
        MessageBox.Show("Please Login First", "Login to Proceed", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Form2.Show()
        Me.Hide()
    End Sub
End Class
